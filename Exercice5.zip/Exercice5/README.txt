Exercice 5: 

1- 

2-

3-
